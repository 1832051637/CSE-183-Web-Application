"""
This file defines the database models
"""
import datetime

from .common import db, Field, auth
from pydal.validators import *


def get_user_email():
    return auth.current_user.get('email') if auth.current_user else None


# Get the name of the user
def get_user_name():
    name = auth.current_user.get('first_name') + ' ' + auth.current_user.get(
        'last_name')
    return name


### Define your table below
#
# db.define_table('thing', Field('name'))
#
## always commit your models to avoid problems later
#
# db.commit()
#
db.define_table(
    'contact',
    Field('firstName', requires=IS_NOT_EMPTY()),
    Field('lastName', requires=IS_NOT_EMPTY()),
    Field('user_email', default=get_user_email),
)

db.define_table(
    'phone',
    Field('number', requires=IS_NOT_EMPTY()),
    Field('name', requires=IS_NOT_EMPTY()),
    Field('contact_id', 'reference contact'),
)

db.contact.user_email.readable = True
db.contact.user_email.writable = False
db.contact.id.readable = db.contact.id.writable = False
db.phone.id.readable = db.phone.id.writable = False
db.phone.contact_id.readable = db.phone.contact_id.writable = False

db.commit()
