// This will be the object that will contain the Vue attributes
// and be used to initialize it.
let app = {};


// Given an empty app object, initializes it filling its attributes,
// creates a Vue instance, and then initializes the Vue instance.
let init = (app) => {

    // This is the Vue data.
    app.data = {
        // Complete as you see fit.
        add_mode: false,
        add_text: "Add your post here...",
        rows: [],
        curr_email: "",
        curr_name: ""
    };

    app.enumerate = (a) => {
        // This adds an _idx field to each element of the array.
        let k = 0;
        a.map((e) => { e._idx = k++; });
        return a;
    };

    app.add_post = function () {
        axios.post(add_post_url,
            {
                text: app.vue.add_text,
                _state: { post: "clean" },
            }).then(function (response) {
                app.vue.rows.push({
                    id: response.data.id,
                    email: response.data.email,
                    text: app.vue.add_text,
                    name: response.data.name,
                    show_likers: false,
                    show_dislikers: false,
                    liked: -1,
                    likers: ["No liker", "and no liker"],
                    dislikers: ["No disliker", "and no disliker"],
                    _state: { post: "clean" },
                    _server_vals: {
                        text: app.vue.add_text,
                    }
                });
                app.enumerate(app.vue.rows);
                app.reset_form();
                app.set_add_status(false);
            });
    };

    app.set_likers = function (row_idx, val) {
        app.vue.rows[row_idx].show_likers = val;
    }

    app.set_dislikers = function (row_idx, val) {
        app.vue.rows[row_idx].show_dislikers = val;
    }

    app.add_liker = function (row_idx, name) {
        app.vue.rows[row_idx].likers.push(name)
    }

    app.add_disliker = function (row_idx, name) {
        app.vue.rows[row_idx].dislikers.push(name)
    }

    app.reset_form = function () {
        app.vue.add_text = "";
    };

    app.set_add_status = function (new_status) {
        app.vue.add_mode = new_status;
    };

    app.delete_post = function (row_idx) {
        let id = app.vue.rows[row_idx].id;
        axios.get(delete_post_url, { params: { id: id } }).then(function (response) {
            for (let i = 0; i < app.vue.rows.length; i++) {
                if (app.vue.rows[i].id === id) {
                    app.vue.rows.splice(i, 1);
                    app.enumerate(app.vue.rows);
                    break;
                }
            }
        });
    };

    app.get_delete_status = function (post_email) {
        return app.vue.curr_email == post_email;
    };


    app.enumerate = (a) => {
        // This adds an _idx field to each element of the array.
        let k = 0;
        a.map((e) => { e._idx = k++; });
        return a;
    };

    app.decorate = (a) => {
        a.map((e) => {
            e._state = { name: "clean", text: "clean", email: "clean" };
            e._server_vals = { name: e.name, text: e.text, email: e.email };
        });
        return a;
    };

    app.init_rows = (rows) => {
        rows.map((r) => {
            r.show_likers = false;
            r.show_dislikers = false;
            r.likers = ["No liker", "and no liker"];
            r.dislikers = ["No disliker", "and no disliker"];
            r.liked = -1
        })
    };
    // This contains all the methods.
    app.methods = {
        // Complete as you see fit.
        add_post: app.add_post,
        set_add_status: app.set_add_status,
        delete_post: app.delete_post,
        get_delete_status: app.get_delete_status,
        set_likers: app.set_likers,
        set_dislikers: app.set_dislikers,
        add_liker: app.add_liker,
        add_disliker: app.add_disliker,
    };

    // This creates the Vue instance.
    app.vue = new Vue({
        el: "#vue-target",
        data: app.data,
        methods: app.methods
    });

    // And this initializes it.
    app.init = () => {
        // Put here any initialization code.
        // Typically this is a server GET call to load the data.
        axios.get(load_post_url).then(function (response) {
            let rows = response.data.rows;
            rows = app.decorate(app.enumerate(rows));
            app.init_rows(rows);
            app.vue.rows = rows
            app.vue.curr_email = response.data.curr_email
            app.vue.curr_name = response.data.curr_name
            app.init_rows()
        });
    };

    // Call to the initializer.
    app.init();
};

// This takes the (empty) app object, and initializes it,
// putting all the code i
init(app);
