// This will be the object that will contain the Vue attributes
// and be used to initialize it.
let app = {};


// Given an empty app object, initializes it filling its attributes,
// creates a Vue instance, and then initializes the Vue instance.
let init = (app) => {

    // This is the Vue data.
    app.data = {
        // Complete as you see fit.
        add_mode: false,
        add_text: "Add your post here...",
        rows: [],
        curr_email: "",
        curr_name: ""
    };

    app.enumerate = (a) => {
        // This adds an _idx field to each element of the array.
        let k = 0;
        a.map((e) => { e._idx = k++; });
        return a;
    };

    app.add_post = function () {
        axios.post(add_post_url,
            {
                text: app.vue.add_text,
                _state: { post: "clean" },
            }).then(function (response) {
                app.vue.rows.push({
                    id: response.data.id,
                    email: response.data.email,
                    text: app.vue.add_text,
                    name: response.data.name,
                    show_likers: false,
                    show_dislikers: false,
                    liked: false,
                    disliked: false,
                    likers: [],
                    dislikers: [],
                    _state: { post: "clean" },
                    _server_vals: {
                        text: app.vue.add_text,
                    }
                });
                app.enumerate(app.vue.rows);
                app.reset_form();
                app.set_add_status(false);
            });
    };

    app.set_show_likers = function (row_idx, val) {
        if (app.vue.rows[row_idx].likers.length > 0) {
            app.vue.rows[row_idx].show_likers = val;
        }
    }

    app.set_show_dislikers = function (row_idx, val) {
        if (app.vue.rows[row_idx].dislikers.length > 0) {
            app.vue.rows[row_idx].show_dislikers = val;
        }
    }

    app.like = function (row_idx, name) {
        if (app.vue.rows[row_idx].liked) {
            app.vue.rows[row_idx].liked = false;
            // app.vue.rows[row_idx].disliked = false;
            app.set_show_likers(row_idx, false)
            // app.set_show_dislikers(row_idx, false)
            let i = app.vue.rows[row_idx].likers.indexOf(name)
            if (i !== -1) {
                app.vue.rows[row_idx].likers.splice(i, 1)
            }
            return
        }

        app.vue.rows[row_idx].liked = true;
        app.vue.rows[row_idx].disliked = false;
        if (app.vue.rows[row_idx].likers.includes(name)) {
            return;
        }
        app.vue.rows[row_idx].likers.push(name);
        app.set_show_likers(row_idx, true)
        app.set_show_dislikers(row_idx, false)
        let i = app.vue.rows[row_idx].dislikers.indexOf(name)
        if (i !== -1) {
            app.vue.rows[row_idx].dislikers.splice(i, 1)
        }


    }

    app.dislike = function (row_idx, name) {
        if (app.vue.rows[row_idx].disliked) {
            // app.vue.rows[row_idx].liked = false;
            app.vue.rows[row_idx].disliked = false;
            // app.set_show_likers(row_idx, false)
            app.set_show_dislikers(row_idx, false)
            let i = app.vue.rows[row_idx].dislikers.indexOf(name);
            if (i !== -1) {
                app.vue.rows[row_idx].dislikers.splice(i, 1);
            }
            return
        }

        app.vue.rows[row_idx].show_dislikers = true;
        app.vue.rows[row_idx].liked = false;
        app.vue.rows[row_idx].disliked = true;
        if (app.vue.rows[row_idx].dislikers.includes(name)) {
            return;
        }
        app.vue.rows[row_idx].dislikers.push(name)
        app.set_show_likers(row_idx, false)
        app.set_show_dislikers(row_idx, true)
        let i = app.vue.rows[row_idx].likers.indexOf(name)
        if (i !== -1) {
            app.vue.rows[row_idx].likers.splice(i, 1)
        }
    }

    // app.set_dislike = function (row_idx, val) {
    //     app.vue.rows[row_idx].show_dislikers = val;
    // }
    app.reset_form = function () {
        app.vue.add_text = "";
    };

    app.set_add_status = function (new_status) {
        app.vue.add_mode = new_status;
    };

    app.delete_post = function (row_idx) {
        let id = app.vue.rows[row_idx].id;
        axios.get(delete_post_url, { params: { id: id } }).then(function (response) {
            for (let i = 0; i < app.vue.rows.length; i++) {
                if (app.vue.rows[i].id === id) {
                    app.vue.rows.splice(i, 1);
                    app.enumerate(app.vue.rows);
                    break;
                }
            }
        });
    };

    app.get_delete_status = function (post_email) {
        return app.vue.curr_email == post_email;
    };


    app.enumerate = (a) => {
        // This adds an _idx field to each element of the array.
        let k = 0;
        a.map((e) => { e._idx = k++; });
        return a;
    };

    app.decorate = (a) => {
        a.map((e) => {
            e._state = { name: "clean", text: "clean", email: "clean" };
            e._server_vals = { name: e.name, text: e.text, email: e.email };
        });
        return a;
    };

    app.init_rows = (rows) => {
        rows.map((r) => {
            r.show_likers = false;
            r.show_dislikers = false;
            r.likers = [];
            r.dislikers = [];
            r.liked = false;
            r.disliked = false;
        })
        app.vue.rows = rows
    };
    // This contains all the methods.
    app.methods = {
        // Complete as you see fit.
        add_post: app.add_post,
        set_add_status: app.set_add_status,
        delete_post: app.delete_post,
        get_delete_status: app.get_delete_status,
        set_show_likers: app.set_show_likers,
        set_show_dislikers: app.set_show_dislikers,
        like: app.like,
        dislike: app.dislike,
    };

    // This creates the Vue instance.
    app.vue = new Vue({
        el: "#vue-target",
        data: app.data,
        methods: app.methods
    });

    // And this initializes it.
    app.init = () => {
        // Put here any initialization code.
        // Typically this is a server GET call to load the data.
        axios.get(load_post_url).then(function (response) {
            // let rows = response.data.rows;
            let rows = app.decorate(app.enumerate(response.data.rows));
            app.init_rows(rows);

            app.vue.curr_email = response.data.curr_email
            app.vue.curr_name = response.data.curr_name
            // app.init_rows()
        });
    };

    // Call to the initializer.
    app.init();
};

// This takes the (empty) app object, and initializes it,
// putting all the code i
init(app);
