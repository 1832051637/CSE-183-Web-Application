1) gem install sass
2) download bulma to css/bulma
2) edit bulma vars in muystyles.scss
3) run:
    sass --sourcemap=none sass/mystyles.scss:custom-css/mystyles.css or make css
4) sass --watch ... (or make watch) to watch for updates and remake automatically
